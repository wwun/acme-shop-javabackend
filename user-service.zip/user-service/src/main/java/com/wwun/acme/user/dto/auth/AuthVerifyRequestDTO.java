package com.wwun.acme.user.dto.auth;

public record AuthVerifyRequestDTO(String username, String password) {}
