package com.wwun.acme.user.enums;

public enum RolesEnum {
    ROLE_ADMIN, ROLE_USER
}