package com.wwun.acme.security;

public enum AuthProviderEnum {
    LOCAL,GOOGLE,GITHUB
}
