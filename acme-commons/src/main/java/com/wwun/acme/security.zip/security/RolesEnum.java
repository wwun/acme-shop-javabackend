package com.wwun.acme.security;

public enum RolesEnum {
    ROLE_ADMIN, ROLE_USER
}