package com.wwun.acme.product.exception;

public class ProductNotFoundException extends BaseException{

    public ProductNotFoundException(String message) {
        super(message);
    }

}
