package com.wwun.acme.product.enums;

public enum StockOperation {
    INCREASE, DECREASE, SET
}
