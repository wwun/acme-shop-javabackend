package com.wwun.acme.product.exception;

public class CategoryNotFoundException extends BaseException{

    public CategoryNotFoundException(String message){
        super(message);
    }
    
}
