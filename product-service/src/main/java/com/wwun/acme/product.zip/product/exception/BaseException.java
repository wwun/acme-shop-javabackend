package com.wwun.acme.product.exception;

public class BaseException extends RuntimeException{
    public BaseException(String message){
        super(message);
    }
}
