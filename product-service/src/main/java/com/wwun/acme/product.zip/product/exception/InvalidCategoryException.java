package com.wwun.acme.product.exception;

public class InvalidCategoryException extends BaseException{

    public InvalidCategoryException(String message){
        super(message);
    }
}
