package com.wwun.acme.product.exception;

public class InvalidStockAmountException extends BaseException{

    public InvalidStockAmountException(String message){
        super(message);
    }

}
