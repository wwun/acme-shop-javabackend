package com.wwun.acme.product.exception;

public class InvalidProductException extends BaseException{

    public InvalidProductException(String message){
        super(message);
    }

}
