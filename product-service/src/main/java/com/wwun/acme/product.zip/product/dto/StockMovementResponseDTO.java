package com.wwun.acme.product.dto;

import com.wwun.acme.product.enums.StockOperation;

public class StockMovementResponseDTO {
    private Integer amount;
    private StockOperation operation;
    
    public Integer getAmount() {
        return amount;
    }
    public void setAmount(Integer amount) {
        this.amount = amount;
    }
    public StockOperation getOperation() {
        return operation;
    }
    public void setOperation(StockOperation operation) {
        this.operation = operation;
    }

    
}
