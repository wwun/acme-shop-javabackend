package com.wwun.acme.product.exception;

public class InsufficientStockException extends BaseException{

    public InsufficientStockException(String message){
        super(message);
    }
}
