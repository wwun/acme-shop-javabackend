package com.wwun.acme.product.service;

import java.util.Optional;

import com.wwun.acme.product.entity.StockMovement;
import com.wwun.acme.product.repository.StockMovementRepository;

public class StockMovementServiceImpl implements StockMovementService{

    private final StockMovementRepository stockMovementRepository;

    public StockMovementServiceImpl(StockMovementRepository stockMovementRepository){
        this.stockMovementRepository = stockMovementRepository;
    }

    public StockMovement save(StockMovement stockMovement){
        return stockMovementRepository.save(stockMovement);
    }
}
