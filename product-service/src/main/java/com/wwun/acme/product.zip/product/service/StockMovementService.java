package com.wwun.acme.product.service;

import java.util.Optional;

import com.wwun.acme.product.entity.StockMovement;

public interface StockMovementService {

    StockMovement save(StockMovement StockMovement);

}
